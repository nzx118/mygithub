# -*- coding: UTF-8 -*-
import os
import time
import math
#import numpy
import arcpy                                                                     #引入arcpy模块
from arcpy.sa import *

arcpy.CheckOutExtension("spatial")
arcpy.CheckOutExtension("GeoStats")

arcpy.env.overwriteOutput = True

pyqShp = os.getcwd()+'/PYQ.shp'

nowTime = time.strftime("%Y-%m-%d %H.%M.%S", time.localtime())
os.mkdir(nowTime)
dataPath = os.getcwd()+'/'+nowTime                                               #设定路径
imagePath = dataPath+'/image'
os.mkdir(imagePath)
gdbName = 'data.gdb'
arcpy.env.workspace = 'in_memory'
arcpy.CreateFileGDB_management(dataPath, gdbName)
arcpy.env.workspace = dataPath+'/'+gdbName
boundaryWhere = "CHFCID=13700"
boundaryCursor = arcpy.da.SearchCursor(pyqShp, ["SHAPE@"], boundaryWhere)
boundaryExtent = boundaryCursor.next()[0].extent
del boundaryCursor
arcpy.env.extent = arcpy.Extent(boundaryExtent.XMin-0.02,boundaryExtent.YMin-0.02,boundaryExtent.XMax+0.02,boundaryExtent.YMax+0.02)
boundary = 13700
arcpy.MakeFeatureLayer_management(pyqShp, boundary, boundaryWhere)
#contourValues = "2;4;8;12;20;30;50"
contourValues = "1;2;3;4;5;6;7;8;9;10"
#contourValues = "0.5;1;1.5;2;2.5;3;3.5;4;4.5;5;6;7;8;9;10"
#years = [2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016]
years = [2007]
months = ['01','02','03','04','05','06','07','08','09','10','11','12']             #选择作图月份
for year in years:
    print year
    for month in months:
        print month
        dateTime = str(year)+month
        folderPath = dataPath+"\\"+dateTime
        os.mkdir(folderPath)
        pointsPath = os.getcwd()+"\\" + str(year)+ "\\" +dateTime
        pointsLayer = pointsPath+"\\points.shp"
        outKrig = Kriging(pointsLayer, 'bd2', 'SPHERICAL', 0.02)                   #运用克里金方法进行插值
        krigPath = folderPath+'/interpolation.tif'                                 #输入插值结果文件
        outKrig.save(krigPath)
        coutourPath = 'in_memory/contour'
        smoothResult = 'in_memory/smoothLine'
        isolinePath = folderPath+'\\'+'isoline.shp'                                #生成等值线isoline.shp
        ContourList(krigPath, coutourPath, contourValues)
        arcpy.SmoothLine_cartography(coutourPath, smoothResult, "PAEK", 0.05, "FIXED_CLOSED_ENDPOINT", "NO_CHECK")
        arcpy.Clip_analysis(smoothResult,boundary,isolinePath)
        #mxd = arcpy.mapping.MapDocument(r"C:\\Users\\nong\\Desktop\\test\\13700.mxd")
        mxd = arcpy.mapping.MapDocument(os.getcwd()+"\\13700.mxd")
        timeStr = ''                                                               #更改标题
        for i in range(4):
            letter = dateTime[i]
            if(letter=='0'):
                timeStr += u'〇'
            elif(letter=='1'):
                timeStr += u'一'
            elif(letter=='2'):
                timeStr += u'二'
            elif(letter=='3'):
                timeStr += u'三'
            elif(letter=='4'):
                timeStr += u'四'
            elif(letter=='5'):
                timeStr += u'五'
            elif(letter=='6'):
                timeStr += u'六'
            elif(letter=='7'):
                timeStr += u'七'
            elif(letter=='8'):
                timeStr += u'八'
            elif(letter=='9'):
                timeStr += u'九'
        timeStr += u'年'
        month = int(dateTime[4:6])
        if(month==1):
            timeStr += u'一月'
        elif(month==2):
            timeStr += u'二月'
        elif(month==3):
            timeStr += u'三月'
        elif(month==4):
            timeStr += u'四月'
        elif(month==5):
            timeStr += u'五月'
        elif(month==6):
            timeStr += u'六月'
        elif(month==7):
            timeStr += u'七月'
        elif(month==8):
            timeStr += u'八月'
        elif(month==9):
            timeStr += u'九月'
        elif(month==10):
            timeStr += u'十月'
        elif(month==11):
            timeStr += u'十一月'
        elif(month==12):
            timeStr += u'十二月'
        for elm in arcpy.mapping.ListLayoutElements(mxd,"TEXT_ELEMENT","title"):
            newTitle = elm.text.replace(u'二〇〇三年一月',timeStr,1)
            print newTitle
            elm.text = newTitle
        #mxd.findAndReplaceWorkspacePaths(r"C:\\Users\\nong\\Desktop\\test\\isoline\\isoline.shp", folderPath+'/isoline.shp')
        df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]                          #在工程中添加等值线lsoline.shp并成图
        refLayer = arcpy.mapping.ListLayers(mxd, "geo_prov_5t_cx", df)[0]
        insertLayer = arcpy.mapping.Layer(folderPath+"/isoline.shp")
        arcpy.mapping.InsertLayer(df, refLayer, insertLayer, "BEFORE")
        updateLayer = arcpy.mapping.ListLayers(mxd, "isoline", df)[0]
        #sourceLayer = arcpy.mapping.Layer(r"C:/Users/nong/Desktop/test/isoline.lyr")
        sourceLayer = arcpy.mapping.Layer(os.getcwd()+"/isoline.lyr")
        arcpy.mapping.UpdateLayer(df, updateLayer, sourceLayer, True)
        #updateLayer.labelClasses.expression("Contour")
        updateLayer.expression="Contour"
        updateLayer.showLabels = True
        #addLayer = arcpy.mapping.Layer("E:\\gis\\Jiangsu\\points.lyr")
        #addLayer.replaceDataSource(pointsPath,"SHAPEFILE_WORKSPACE","points")
        #arcpy.mapping.AddLayer(df, addLayer, "TOP")
        mxd.saveACopy(folderPath+'/13700.mxd')                                       #另存工程
        arcpy.mapping.ExportToPNG(mxd, imagePath+'/'+dateTime+'.png', 'PAGE_LAYOUT', 297, 420, 300)
        del mxd
        arcpy.Delete_management("in_memory")
