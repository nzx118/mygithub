﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DisplayScore : MonoBehaviour {

    Text Display;
    int Score;
    // Use this for initialization
    void Start () {
        Display = GetComponent<Text>();

	}
    public void Addpoints(int score) {
        this.Score += score;
        Display.text = "得分：" + this.Score;
    }

    public void Reduce(int score){
        this.Score -= score;
        Display.text = "得分：" + this.Score;
        if (this.Score<0)
        {
            SceneManager.LoadScene("lose");
        }
    }
	
	// Update is called once per frame
	void Update () {
        
	}
}
