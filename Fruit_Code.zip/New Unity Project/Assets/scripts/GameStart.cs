﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GameStart : MonoBehaviour {
    public GameObject[] FruitMaterial;
    public GameObject BombMaterial;
    public float TimeInterval=1;//时间间隔
    private float Timer=0;//计时器
    private float PosZ;
    private AudioSource aud;
 


	void Update () {
      
        Timer += Time.deltaTime;
        if (Timer >= TimeInterval) {
            Timer -= TimeInterval;
          
            if (Random.value >= 0) {//判断生成炸弹
                Fruitout(false);
            }
            int num = Random.Range(3, 6);
            for (int i = 0; i < num; i++)
            {
                Fruitout(true);
            }
            
            
 }
	}
    
    void Fruitout(bool isFruit)
    {

        PosZ -= 2;
        aud = GetComponent<AudioSource>();
       if (PosZ <= -2)
        {
            PosZ = transform.position.z;
        }
        //随机出视口坐标系的点
        Vector3 ViewPort = new Vector3(Random.value, 0, 0);
    //视口坐标系的点转为世界坐标系的点
    Vector3 Worldpoint = Camera.main.ViewportToWorldPoint(ViewPort);
        //定义炸弹或水果坐标
        Vector3 pos = new Vector3(Worldpoint.x, transform.position.y, PosZ);


            if (isFruit)
        {
            //初始化水果
            GameObject Initiate = Instantiate<GameObject>(FruitMaterial[Random.Range(0, FruitMaterial.Length)], pos, Random.rotation );
            Initiate.GetComponent<Rigidbody>().velocity = new Vector3(-pos.x * Random.Range(0f, 0.8f), -Physics.gravity.y * Random.Range(1.5f, 1.8f), 0);
            // Initiate.GetComponent<Rigidbody>().velocity = new Vector3(-pos.x*Random.Range(0f,0.8f),-Physics.gravity.y*Random.Range(1f,1.6f),-PosZ*Random.Range(0f,0.5f));
            aud.Play();
        }
        else {
            GameObject Initiate= Instantiate<GameObject>(BombMaterial, pos, Random.rotation);
            // Initiate.GetComponent<Rigidbody>().velocity = new Vector3(-pos.x * Random.Range(0f, 0.8f), -Physics.gravity.y * Random.Range(1f, 1.6f), -PosZ * Random.Range(0f, 0.3f));
            Initiate.GetComponent<Rigidbody>().velocity = new Vector3(-pos.x * Random.Range(0f, 0.8f), -Physics.gravity.y * Random.Range(1.5f, 1.8f),0);
        }

    }

    void OnCollisionEnter(Collision Fruit)
    {
       Destroy( Fruit.gameObject);
    }

}
