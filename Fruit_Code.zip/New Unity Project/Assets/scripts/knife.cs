﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class knife : MonoBehaviour {
    public bool IsDouble=false;
    public float TimeInterval = 1;//时间间隔
    public float Timer = 0;//计时器
    LineRenderer line;
    bool isbuttonhold=  false;
    bool isfirstclick = false;
    private Vector3[] Points;//存点数组
    private Vector3 Currentpoint;
    private Vector3 Lastpoint;
    private int Pointcount=0; //数组中点的个数
    private AudioSource aud;
    
	
	void Start () {
        line = GetComponent<LineRenderer>();
        int total = line.positionCount = 20;//显示的点个数
        Points = new Vector3[total];//创建存放显示点数组
        aud = GetComponent<AudioSource>();

    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            IsDouble = true;
            Timer = Time.deltaTime;
            if (Timer >= TimeInterval) {
                Timer = 0;
                IsDouble = false;
            }
            aud.Play();//点击鼠标发出挥刀音效
            isfirstclick = true;
            isbuttonhold = true;

        }else
        if (Input.GetMouseButtonUp(0))
        {
            isbuttonhold = false;
            Points = new Vector3[line.positionCount];//鼠标弹起时重置数组
        }
        DrawLine();//放在isfirstclick=false之前
        isfirstclick = false;

	}
    void DrawLine()
    {
        if (isfirstclick) {
            Currentpoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Lastpoint = Currentpoint;
            Pointcount = 0;//每次第一次点击的时候数组重置
        }
        if (isbuttonhold)
        {
            Currentpoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            
            float distance= Vector3.Distance(Currentpoint, Lastpoint);//判断当前和上一点的距离
            if (distance>=0.01f)
            {
                SavePoint(Currentpoint);
                CutFruits(Currentpoint);//切水果
                Pointcount++;
            }
            Lastpoint = Currentpoint;//记录完当前值后，变为lastpoint
        }
        ChangePoints(Points);

    }
    void SavePoint(Vector3 pos) {
        pos.z = 0;
        if (Pointcount < line.positionCount)//若没存满，则数组中后面的数等于最后存放的数
        {
            for (int i = Pointcount; i < line.positionCount; i++)
            {
                Points[i] = pos;
            }
        }
        else {
            for (int i = 0; i < line.positionCount-1; i++)//存满后，每个数往前一位进，最后一个数存放当前值
            {
                Points[i] = Points[i + 1];
            }
            Points[line.positionCount-1] = pos;//错1，更新最后一点
        }
    }

    void ChangePoints(Vector3[] pos ) {//更新显示点
        line.SetPositions(pos);
    }

    void CutFruits(Vector3 pos) {
        Vector3 Viewport = Camera.main.WorldToViewportPoint(pos);
        Ray ray = Camera.main.ViewportPointToRay(Viewport);
        RaycastHit[] hits = Physics.RaycastAll(ray);
       
        for (int i = 0; i < hits.Length; i++)
        {
            hits[i].collider.GetComponent<Fruit>().Cut();
        }
    }
}
