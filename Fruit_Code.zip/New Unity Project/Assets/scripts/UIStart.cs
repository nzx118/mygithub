﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;//引入UI名词空间
using UnityEngine.SceneManagement; //场景切换名词空间

public class UIStart : MonoBehaviour
{
    public Sprite Sound1;
    public Sprite Sound2;
    public AudioSource Audio;
    private Button ButtonPlay;       //定义按钮
    private Button ButtonVoice;
    private Button ButtonQuit;
    private Image Sound;
    
    

    void Start()
    {
        ButtonPlay = transform.Find("Button-Play").GetComponent<Button>();        //获取两个按钮的Button值
        ButtonVoice = transform.Find("Button-Voice").GetComponent<Button>();
        ButtonQuit = transform.Find("ButtonQuit").GetComponent<Button>();
        Sound = ButtonVoice.GetComponent<Image>();

        ButtonPlay.onClick.AddListener(Play);                                   
        ButtonVoice.onClick.AddListener(Mute);
        ButtonQuit.onClick.AddListener(Quit);//当按下按钮时调用方法
    }

    void Mute() {
        if (Audio.mute)
        {
            Audio.mute = false;
            Sound.sprite = Sound2;
        }
        else {
            Audio.mute = true;
            Sound.sprite = Sound1;
        }
        
    }

    void Play(){
        SceneManager.LoadScene("Game");
    }

    void Quit()
    {
        Application.Quit();

    }

}


