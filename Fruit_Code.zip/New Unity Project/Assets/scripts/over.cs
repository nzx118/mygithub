﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class over : MonoBehaviour {
    private Button Replay;
    private Button Main1;
    private Button quit;

    void Start() {
        Replay = transform.Find("Button-Play").GetComponent<Button>();
        Main1 = transform.Find("Button-main").GetComponent<Button>();
        quit = transform.Find("Button-quit").GetComponent<Button>();
        Replay.onClick.AddListener(play);
        Main1.onClick.AddListener(main1);
        quit.onClick.AddListener(Quit);
    }
       void play() {
        SceneManager.LoadScene("Game");
    }

    void main1() {
        SceneManager.LoadScene("Start");
    }

    void Quit() {
        Application.Quit();
    }

}
