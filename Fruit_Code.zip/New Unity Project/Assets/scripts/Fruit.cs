﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fruit : MonoBehaviour {
    private knife D;
    public AudioClip aud;
    public GameObject Firework;
    public GameObject halffruit;
    public GameObject Splash;
    public GameObject SplashFlat;
    private DisplayScore displayScore;

    void Start() {
      displayScore=  GameObject.Find("Text-score").GetComponent<DisplayScore>();
    }

   public void Cut() {
        AudioSource.PlayClipAtPoint(aud, Camera.main.transform.position, 0.2f);
        if (this.tag == "Bomb")
        {//碰到炸弹
            displayScore.Reduce(100);
            Destroy(gameObject);
            Instantiate(Firework, transform.position, Random.rotation);
        }
        else {
            displayScore.Addpoints(10);
            for (int i = 0; i < 2; i++)
            {//碰到水果
 
                Destroy(gameObject);
                GameObject Initiate = Instantiate<GameObject>(halffruit, transform.position, Random.rotation);
                Destroy(Initiate, 5);
                GameObject S=  Instantiate(Splash, transform.position, Random.rotation);
                Destroy(S, 5);//延迟销毁
                Initiate.GetComponent<Rigidbody>().AddForce(Random.insideUnitSphere*10, ForceMode.Impulse);
            }
            GameObject SF= Instantiate(SplashFlat, transform.position, Random.rotation);
            Destroy(SF, 5);
        }
        Destroy(gameObject);
    }
}
